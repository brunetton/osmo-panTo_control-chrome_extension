# osmo.mobi panTo control

Add a button to osmo.mobi to enable/disable auto map recenter.

![](screenshot.png)

## Installation



## Usage :

When plugin activated, you should see a new button appear in the right top of the screen.
Just click on it to toggle auto map recenter.

## Source code

https://github.com/brunetton/osmo-panTo_control-chrome_extension